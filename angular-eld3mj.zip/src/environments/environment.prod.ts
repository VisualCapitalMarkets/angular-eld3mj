export const environment = {
  production: true,
  host: 'http://admin.d-mag.pro:3000'
};
